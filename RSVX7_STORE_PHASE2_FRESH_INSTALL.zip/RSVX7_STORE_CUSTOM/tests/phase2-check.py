#!/usr/bin/env python3
"""Offline structural regression tests. No orders or payments are made."""
from pathlib import Path
import json

root = Path(__file__).resolve().parents[1]
required = (
    'src/app/api/cart/route.ts',
    'src/app/api/cart/[action]/route.ts',
    'src/app/api/checkout/route.ts',
    'src/app/order-confirmation/page.tsx',
    'src/app/api/order/receipt/route.ts',
    'src/lib/cart-server.ts',
    'src/lib/receipt.ts',
    'src/components/checkout-client.tsx',
    'deploy/upgrade-phase2.sh',
    'deploy/woo-readiness.sh',
)
for name in required:
    path = root / name
    assert path.is_file(), name
    assert path.stat().st_size > 100, name

checkout = (root / 'src/app/api/checkout/route.ts').read_text()
cart = (root / 'src/lib/cart-server.ts').read_text()
receipt = (root / 'src/lib/receipt.ts').read_text()
compose = (root / 'compose.yaml').read_text()

checks = {
    'checkout validates origin': 'requireSameOrigin(req)' in checkout,
    'checkout verifies live Woo cart': "requestWoo('/cart', 'GET')" in checkout,
    'checkout verifies server-side total': 'total !== data.expected_total' in checkout,
    'checkout verifies allowed payment methods': 'methods.includes(payment)' in checkout,
    'checkout blocks physical shipping': 'needs_shipping === true' in checkout,
    'checkout serializes duplicate request per cart': 'inFlight.has(cartToken)' in checkout,
    'checkout does not disclose raw order keys': 'order_key' not in checkout,
    'checkout does not auto-grant digital files': 'download_permissions' not in checkout,
    'Woo token cookie is HTTP-only': 'httpOnly: true' in cart,
    'Woo session cookie is same-site': "sameSite: 'lax'" in cart,
    'no Woo nonce check disabled': 'disable_nonce_check' not in cart,
    'receipt protected by HMAC': "createHmac('sha256'" in receipt,
    'receipt constant-time signature check': 'timingSafeEqual' in receipt,
    'receipt secret is passed to container': 'WC_RECEIPT_SECRET:' in compose,
    'dependencies are pinned': json.loads((root/'package.json').read_text())['overrides']['motion-dom'] == '12.23.12',
}
for label, ok in checks.items():
    print(('PASS' if ok else 'FAIL'), label)
assert all(checks.values())
print('PASS: all phase 2 offline structural checks')
