import { notFound } from 'next/navigation'
import Image from 'next/image'
import Link from 'next/link'
import type { Metadata } from 'next'
import { ArrowLeft, ShieldCheck, Download, PackageCheck } from 'lucide-react'
import { getProduct, demoMode } from '@/lib/woocommerce'
import { priceLabel, cleanText } from '@/lib/format'
import { mediaUrl } from '@/lib/media'
import { AddToCart } from '@/components/add-to-cart'
export const dynamic='force-dynamic'
export async function generateMetadata({params}:{params:Promise<{slug:string}>}):Promise<Metadata>{const {slug}=await params;const p=await getProduct(slug);return {title:p?.name||'Product'}}
export default async function ProductPage({params}:{params:Promise<{slug:string}>}){
 const {slug}=await params;const product=await getProduct(slug);if(!product)notFound()
 return <main className="page-main"><div className="container"><Link href="/shop" className="back-link"><ArrowLeft size={17}/> ALL PRODUCTS</Link>{demoMode&&<p className="demo-banner">DEMO MODE · Product details are illustrative. Checkout is disabled.</p>}<div className="detail-grid"><div className="detail-image"><div className="product-mesh"/>{product.images?.[0]?.src?<Image src={mediaUrl(product.images[0].src) || product.images[0].src} alt={product.images[0].alt||product.name} fill unoptimized className="detail-img" sizes="(max-width:850px) 100vw,50vw"/>:<div className="product-placeholder large-placeholder"><span className="placeholder-ring"/><Image src="/logo-mark.png" alt="" width={165} height={165}/><span className="placeholder-index">RSVX7 — DIGITAL COLLECTION</span></div>}</div><div className="detail-info"><span className="eyebrow">DIGITAL GOODS / {product.categories?.[0]?.name||'SOFTWARE'}</span><h1>{product.name}</h1><p className="detail-summary">{cleanText(product.short_description)||'Digital product from RSVX7 STORE.'}</p><div className="detail-price">{priceLabel(product.prices)} <span>USD / INDIVIDUAL LICENSE IF APPLICABLE</span></div><AddToCart product={product}/><div className="detail-benefits"><span><ShieldCheck size={18}/> Secure WooCommerce cart</span><span><PackageCheck size={18}/> Product details managed in WordPress</span><span><Download size={18}/> Digital delivery when configured</span></div><div className="detail-description"><h3>PRODUCT DETAILS</h3><p>{cleanText(product.description)||'Description will be provided by the store administrator.'}</p></div></div></div></div></main>
}
