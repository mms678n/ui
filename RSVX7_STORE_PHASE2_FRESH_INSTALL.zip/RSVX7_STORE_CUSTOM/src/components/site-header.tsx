'use client'
import Link from 'next/link'
import Image from 'next/image'
import { Menu, X, ShoppingBag, ArrowUpRight } from 'lucide-react'
import { useState } from 'react'
export function SiteHeader() {
 const [open,setOpen]=useState(false)
 const links=[['Shop','/shop'],['Collections','/shop#categories'],['Our story','/about'],['My account','/account']]
 return <header className="site-header"><div className="header-inner">
  <Link className="brand" href="/" onClick={()=>setOpen(false)}><span className="brand-symbol"><Image src="/logo-mark.png" alt="" width={26} height={26}/></span><span>RSVX7<span className="brand-light"> / STORE</span></span></Link>
  <nav className="nav-desktop" aria-label="Main navigation">{links.map(([title,path])=><Link key={path+title} href={path}>{title}</Link>)}</nav>
  <div className="header-tools"><Link className="header-cart" href="/cart" aria-label="Shopping cart"><ShoppingBag size={18}/><span className="desktop-text">Cart</span></Link><Link className="header-explore" href="/shop">Explore <ArrowUpRight size={15}/></Link><button className="mobile-toggle" onClick={()=>setOpen(!open)} aria-expanded={open} aria-label="Toggle menu">{open?<X size={23}/>:<Menu size={23}/>}</button></div>
 </div>{open&&<nav className="mobile-nav" aria-label="Mobile navigation">{links.map(([title,path])=><Link key={path+title} href={path} onClick={()=>setOpen(false)}>{title}<ArrowUpRight size={16}/></Link>)}<Link href="/cart" onClick={()=>setOpen(false)}>Cart<ShoppingBag size={17}/></Link></nav>}</header>
}
