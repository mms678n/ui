#!/usr/bin/env bash
set -Eeuo pipefail
HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$HERE"
cp -a package.json "package.json.before-motion-fix.$(date +%Y%m%d-%H%M%S)"
python3 - <<'PYFIX'
import json
from pathlib import Path
p=Path('package.json')
d=json.loads(p.read_text())
if d.get('dependencies',{}).get('framer-motion') != '12.23.12':
    raise SystemExit('Unexpected framer-motion version. Please inspect package.json manually.')
d.setdefault('overrides', {})['motion-dom'] = '12.23.12'
d['overrides']['motion-utils'] = '12.23.6'
p.write_text(json.dumps(d,indent=2)+'\n')
print('Pinned framer-motion companion dependencies.')
PYFIX
echo 'Starting safe rebuild (no volumes/data removed)...'
docker compose build storefront
docker compose up -d --no-build storefront
echo 'Checking service...'
docker compose ps
curl -sS -o /dev/null -w 'Local health HTTP: %{http_code}\n' --max-time 15 http://127.0.0.1:3010/api/health || true
