#!/usr/bin/env bash
# Update the existing custom UI only. Never change Caddy, WordPress, Medusa, or Docker volumes.
set -Eeuo pipefail
HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$HERE"
[[ -f .env ]] || { echo 'ERROR: Existing .env is missing. Use deploy/install.sh for first install.' >&2; exit 1; }
command -v docker >/dev/null
command -v curl >/dev/null
command -v openssl >/dev/null
if ! docker inspect rsvx7-custom-ui >/dev/null 2>&1; then
  echo 'ERROR: Running rsvx7-custom-ui container not found. This is not an existing install.' >&2
  exit 1
fi
# Append new secrets only; keep existing credentials and project settings intact.
umask 077
if ! grep -q '^WC_RECEIPT_SECRET=' .env; then
  cp -p .env ".env.backup-$(date +%Y%m%d-%H%M%S)"
  printf '\nWC_RECEIPT_SECRET=%s\n' "$(openssl rand -hex 32)" >> .env
fi
if ! grep -q '^UI_PUBLIC_URL=' .env; then
  printf 'UI_PUBLIC_URL=https://ui.rsvx7-store.com\n' >> .env
fi
chmod 600 .env

docker compose config --quiet
# Keep image rollback on the same server with shared layers (no data volumes touched).
STAMP="$(date +%Y%m%d-%H%M%S)"
OLD_ID="$(docker inspect -f '{{.Image}}' rsvx7-custom-ui)"
ROLLBACK="rsvx7-custom-ui-phase1-rollback:$STAMP"
docker image tag "$OLD_ID" "$ROLLBACK"
echo "Rollback image: $ROLLBACK"
rollback() {
  echo 'FAILED: Restoring previously running storefront image...' >&2
  docker image tag "$ROLLBACK" rsvx7-custom-ui-storefront:latest
  docker compose up -d --no-build --force-recreate storefront || true
  echo "Original image restored; inspect docker compose ps and logs. Rollback tag: $ROLLBACK" >&2
}
# Compile before replacing the running container.
if ! docker compose --progress plain build storefront; then
  echo 'BUILD FAILED. Previously running container was not replaced.' >&2
  exit 1
fi
if ! docker compose up -d --no-build --force-recreate storefront; then
  rollback
  exit 1
fi
ok=0
for i in $(seq 1 30); do
  status="$(curl -fsS --max-time 5 http://127.0.0.1:3010/api/health 2>/dev/null || true)"
  if [[ "$status" == *'"ok":true'* ]] && curl -fsS -o /dev/null --max-time 12 http://127.0.0.1:3010/; then ok=1; break; fi
  sleep 2
done
if [[ "$ok" != 1 ]]; then
  rollback
  exit 1
fi
printf '\n===== PHASE 2 INSTALLED =====\n'
docker compose ps
printf 'Home: '; curl -sS -o /dev/null -w '%{http_code}\n' http://127.0.0.1:3010/
printf 'Health: '; curl -fsS http://127.0.0.1:3010/api/health; echo
printf 'Cart: '; curl -sS -o /dev/null -w '%{http_code}\n' http://127.0.0.1:3010/api/cart
printf 'Receipt when not purchased: '; curl -sS -o /dev/null -w '%{http_code}\n' http://127.0.0.1:3010/api/order/receipt
printf 'No Caddy or WordPress changes performed.\n'
