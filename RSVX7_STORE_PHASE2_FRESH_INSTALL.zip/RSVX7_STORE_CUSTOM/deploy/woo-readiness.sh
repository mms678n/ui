#!/usr/bin/env bash
# Read-only checks. Does not create orders or change payment settings.
set -Eeuo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$ROOT"
echo '=== FRONTEND HEALTH ==='
curl -fsS --max-time 10 http://127.0.0.1:3010/api/health && echo
echo '=== FRONTEND HOME ==='
curl -sS -o /dev/null --max-time 20 -w 'HTTP %{http_code}\n' http://127.0.0.1:3010/
echo '=== CART API ==='
curl -sS -o /dev/null --max-time 20 -w 'HTTP %{http_code}\n' http://127.0.0.1:3010/api/cart
echo '=== WOOCOMMERCE STATUS ==='
if [[ -f /root/rsvx7-wordpress/compose.yaml ]]; then
  ( cd /root/rsvx7-wordpress && docker compose ps )
else
  echo 'WordPress Compose file not found at its original location.'
fi
echo '=== UI CONTAINER ==='
docker compose ps storefront
echo 'No orders were created and no payment was attempted.'
