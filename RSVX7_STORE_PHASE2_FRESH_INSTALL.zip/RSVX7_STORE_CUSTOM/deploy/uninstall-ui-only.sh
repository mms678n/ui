#!/usr/bin/env bash
# Safely stop ONLY this new UI. No data/volume deletion; no Caddy edits.
set -euo pipefail
cd "$(dirname "$0")/.."
docker compose stop storefront
echo 'RSVX7 custom UI stopped. WordPress and Medusa are untouched.'
echo 'Restore or edit Caddy UI domain separately if needed.'
