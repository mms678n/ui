# RSVX7 STORE — المرحلة 2 (Shopping Flow)

هذه حزمة **تحديث** للمشروع الذي يعمل على `ui.rsvx7-store.com` وليست إعادة تثبيت WooCommerce.

## ما تمت إضافته أو إصلاحه

- Cart-Token من WooCommerce في Cookie من نوع HttpOnly، والتوكن لا يُعرض للمتصفح عبر JavaScript.
- منع POST عبر مواقع خارجية بواسطة مطابقة Origin مع الدومين العام، دون تعطيل فحص nonce في WordPress.
- مراجعة السلة والسعر الإجمالي **مباشرة** من WooCommerce قبل إنشاء الطلب. تغيّر السعر يرجع 409 ولا يرسل الطلب.
- التحقق أن الدفع المختار متاح في إعدادات WooCommerce وسُمح به محليًا؛ الافتراضي `bacs,cheque` فقط.
- منع استخدام صفحة الشراء الرقمية لعربات تحتاج للشحن.
- حماية مؤقتة من إرسال طلبين متزامنين لنفس السلة **داخل عملية تشغيل واحدة**؛ لا توفر التزامن عبر نسخ متعددة.
- صفحة `/order-confirmation`: تعرض حالة الطلب التي رجعت من WooCommerce، دون وصف الطلبات المعلقة بأنها مدفوعة.
- إيصال مؤقت موقّع HMAC لا يضم البريد الإلكتروني أو بيانات الفوترة، محفوظ في HttpOnly Cookie لمدة 24 ساعة. ليس بديلًا عن سجل الطلبات في WordPress.
- إصلاح استمرار الواجهة بدون عرض منتجات وهمية وقت تعطل WordPress (`DEMO_MODE=false`).
- تثبيت نسخ Motion المتوافقة كما في الإصدار المصحح السابق، مع الاحتفاظ بتصميم Cuberto / Linear / Vercel.
- تحديث متدرج مع نسخة من صورة الحاوية القديمة، دون تعديل Caddy أو WordPress أو Volumes.

## تحديث النسخة الموجودة على VPS

1. احفظ نسخة احتياطية من المشروع القديم، مثل:

```bash
cp -a /root/o/RSVX7_STORE_CUSTOM /root/o/RSVX7_STORE_CUSTOM.backup-$(date +%Y%m%d)
```

2. ارفع ملف `RSVX7_STORE_PHASE2.zip` إلى `/root/o/`، ثم:

```bash
cd /root/o
unzip -o RSVX7_STORE_PHASE2.zip
cd /root/o/RSVX7_STORE_CUSTOM
bash deploy/upgrade-phase2.sh
```

- **لا تشغّل سكربت مسح السيرفر**.
- ملف `.env` القديم لا يوجد داخل ZIP ولن يُستبدل. تُضاف قيمة `WC_RECEIPT_SECRET` سرية إلى `.env` إن لم توجد.
- كود التحديث لا يغيّر Caddy أو DNS، ويحاول إعادة صورة الحاوية السابقة إن أخفق اختبار الصحة بعد التشغيل.
- عند فشل البناء لا يتم استبدال الحاوية القديمة.

## فحص ما بعد التحديث

```bash
cd /root/o/RSVX7_STORE_CUSTOM
bash deploy/woo-readiness.sh
docker logs --tail=80 rsvx7-custom-ui
```

## تجربة الشراء بشكل آمن

1. في WooCommerce أنشئ منتجًا **اختباريًا مسموحًا** من نوع Simple، وحدد Virtual وDownloadable وأضف ملفًا حقيقيًا وسعرًا.
2. اجعل المنتج Published وCatalog visibility = Shop and search.
3. من WooCommerce > Settings > Payments فعّل **Direct bank transfer** فقط للتجربة؛ اختبر باستخدام طلب تجريبي دون تحويل أموال حقيقية.
4. افتح `ui.rsvx7-store.com/shop` وأضف المنتج إلى السلة.
5. انتقل إلى `/cart` ثم `/checkout`، راجع السعر واملأ بيانات الطلب التجريبي ثم اضغط Submit Order مرة واحدة.
6. ستظهر `/order-confirmation` مع **ON HOLD** أو حالة WooCommerce الفعلية. **لا تعتبر هذه الرسالة تأكيدًا للدفع**.
7. من WooCommerce > Orders افحص الطلب، ولا تغير حالته إلى Processing/Completed إلا بعد تحقق فعلي من استلام الدفع. لا تحول أموالًا في الاختبار.
8. بعد الدفع المؤكد، يوفّر WooCommerce رابط تنزيل عبر البريد الإلكتروني أو **My Account > Downloads** وفق إعداداته. هذه الملفات لا تُخزَّن ولا تُكشف بواسطة Next.js.
9. اختبر عدم إمكانية تنزيل الملف قبل تأكيد الدفع. اختر طريقة التنزيل Force downloads أو X-Accel-Redirect إن كانت متاحة؛ تجنب Redirect only عندما تحتاج حماية الملفات.
10. **تعمد** تغيير سعر المنتج داخل WooCommerce أثناء فتح Checkout وتحقق أن طلب الشراء يعود بـ409، ولا ينشئ طلبًا بسعر قديم.

**تنبيه:** بعض خطوات الاختبار تتضمن إنشاء طلب تجريبي حقيقي في لوحة WooCommerce (لكن بلا دفع أموال). نفّذها فقط على المنتجات التجريبية.

## حدود المرحلة الثانية

- الربط الحالي يدعم المنتجات `simple` القابلة للشراء؛ المنتجات المتغيرة تحتاج اختيار Variants لاحقًا.
- الدفع يتم فقط عبر طرق **يدوية** تدعم Store API (`bacs`, `cheque`)، ولا يدعم البطاقات أو تحويل الأموال داخل المنصة.
- حسابات العملاء والتنزيلات الحقيقية تبقى في WooCommerce. لا توجد جلسة موحدة بين `ui` و`preview` بعد.
- المحفظة ومفاتيح الترخيص **غير مفعلة** في هذه المرحلة. لن يظهر رصيد وهمي.
- مسار صفحة الإيصال ليس مصدرًا لحالة الدفع المباشرة؛ قد تتغير الحالة من WooCommerce بعد الإنشاء.
- لا يوجد ضمان لمنع الطلبات المكررة بين عدة نسخ من Next.js أو بعد إعادة التشغيل، لذا لا تطلق عدة Replicas قبل وضع قفل/Idempotency دائم.
- لا يمكننا الجزم بنجاح إتمام الطلب أو تسليم الملف قبل تشغيل اختبار تكامل على WooCommerce لديك.
- افصل حماية Basic Auth على دومين WordPress من العملاء المستقبليين عند الإطلاق، مع إبقاء `/wp-admin` محميًا بما يلزم، وبعد اختبار WooCommerce بالكامل.

## تشخيص المشكلة إذا ظهر خطأ

```bash
cd /root/o/RSVX7_STORE_CUSTOM
docker compose ps
docker logs --tail=100 rsvx7-custom-ui
curl -i http://127.0.0.1:3010/api/health
curl -i http://127.0.0.1:3010/api/cart
```

**لا تشارك محتوى `.env` أو ملف `ui-access.txt` أو أسرار WordPress**.

مرجع WooCommerce الرسمي: https://developer.woocommerce.com/docs/apis/store-api/ و https://woocommerce.com/document/digital-downloadable-product-handling/
