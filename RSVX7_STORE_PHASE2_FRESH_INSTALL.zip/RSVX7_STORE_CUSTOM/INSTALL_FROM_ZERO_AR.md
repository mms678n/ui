# RSVX7 STORE Phase 2 — تثبيت جديد من الصفر

هذه الحزمة تحتوي واجهة Next.js مع خدمات WordPress وWooCommerce وMariaDB وCaddy المستقلة. لا تعتمد على مجلدات Medusa أو Caddy السابقة.

## متطلبات
Ubuntu aarch64 أو amd64، Docker Engine وDocker Compose plugin، Python3 وopenssl وcurl وss، 5GB مساحة متاحة، منفذا 80/443 خاليان. يفضّل 4GB RAM أو أكثر. لا تشغّل سكربت تنظيف أو حذف Volumes.

## DNS
في Cloudflare: سجل A باسم `ui` وسجل A باسم `preview` وكلاهما إلى IP السيرفر الصحيح. ابدأ بوضع **DNS only** لحين إصدار Caddy شهادات HTTPS. ستعرض الواجهة على `https://ui.rsvx7-store.com` ولوحة الإدارة على `https://preview.rsvx7-store.com/wp-admin/`.

## تثبيت
```bash
cd /root/ui/RSVX7_STORE_CUSTOM
bash deploy/bootstrap-fresh.sh
```
ملف `fresh-access.txt` يحتوي بيانات WordPress وحماية صفحة الإدارة؛ لا ترسله لأحد، وبدل عنوان بريد الإدارة بعنوان تملكه بعد التثبيت. لا يعيد السكربت التثبيت لو كانت ملفات `.env` موجودة؛ للحفاظ على قاعدة البيانات.

## فحص
```bash
bash deploy/verify-fresh.sh
```
`HTTP 401` على عنوان preview يعني حماية المعاينة موجودة؛ `HTTP 200` على UI يعني أن الواجهة تعمل. يحتاج إصدار الشهادة إلى DNS سليم ووصول 80/443 للإنترنت. افحص `docker compose -f stack/compose.yaml logs caddy` إن فشل HTTPS.

## تفعيل بيع منتج
افتح لوحة WordPress، وأكمل إعداد WooCommerce؛ اضبط **الإعدادات > المدفوعات > التحويل البنكي المباشر** إذا أردت طريقة دفع يدوية اختبارية. أنشئ منتجًا **Virtual + Downloadable** بسعر وصورة وملف تجريبي؛ ثم اختبر السلة وتأكيد الطلب، وتحقق من حالة الطلب قبل توفير التنزيل. طرق الدفع الإلكترونية والمحفظة والتراخيص غير مفعّلة من هذا السكربت.

## أمان
واجهة ui عامة حتى تتمكن من فحصها؛ تُمنع فهرستها مبدئيًا، ولا تروّج لها كموقع بيع نهائي قبل اختبار الطلبات. WordPress preview محمي بكلمة مرور HTTP Basic Auth. خزّن كلمة المرور وملفات `.env` خارج المستودعات العامة ولا تشارك السجلات التي تحتوي الأسرار. خذ نسخة احتياطية من مجلد المشروع وDocker volumes قبل كل تحديث مستقبلي.

## عند انقطاع تثبيت البناء
إذا نجح إنشاء WordPress وانقطع بناء الواجهة، **لا تعِد توليد كلمات المرور أو تحذف القاعدة**؛ نفّذ:
```bash
cd /root/ui/RSVX7_STORE_CUSTOM
bash deploy/resume-fresh.sh
```
إذا لم يكتمل تثبيت WordPress نفسه، فافحص سجل الخدمات وأصلح الخطأ دون حذف البيانات.
