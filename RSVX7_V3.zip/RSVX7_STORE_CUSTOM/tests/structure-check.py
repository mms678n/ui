from pathlib import Path
root = Path(__file__).resolve().parents[1]
required = [
    'src/app/page.tsx',
    'src/app/shop/page.tsx',
    'src/app/cart/page.tsx',
    'src/app/checkout/page.tsx',
    'src/app/account/page.tsx',
    'src/app/reset-password/page.tsx',
    'src/app/wallet/page.tsx',
    'src/app/api/cart/route.ts',
    'src/app/api/checkout/route.ts',
    'src/app/api/auth/[action]/route.ts',
    'src/app/api/account/[resource]/route.ts',
    'src/app/api/download/[id]/route.ts',
    'src/lib/account-server.ts',
    'src/lib/cart-server.ts',
    'src/components/hero.tsx',
    'src/components/site-header.tsx',
    'src/components/account/account-hub.tsx',
    'wordpress/rsvx7-bridge/rsvx7-bridge.php',
    'deploy/upgrade-v3.sh',
    'deploy/backup-v3.sh',
    'deploy/maintenance-check.sh',
    'Dockerfile',
    'compose.yaml',
]
missing = [item for item in required if not (root/item).is_file()]
assert not missing, f'Missing files: {missing}'
assert 'standalone' in (root/'next.config.ts').read_text()
assert 'stack' in (root/'.dockerignore').read_text().splitlines()
assert 'backups' in (root/'.dockerignore').read_text().splitlines()
print(f'PASS: {len(required)} core files and deployment hygiene')
