from pathlib import Path
import re
import shutil
import subprocess
root = Path(__file__).resolve().parents[1]
required = [
    'wordpress/rsvx7-bridge/rsvx7-bridge.php',
    'src/lib/account-server.ts',
    'src/app/api/auth/[action]/route.ts',
    'src/app/api/account/[resource]/route.ts',
    'src/app/api/download/[id]/route.ts',
    'src/app/api/checkout/route.ts',
    'src/components/account/account-hub.tsx',
    'src/components/account/password-reset.tsx',
    'src/app/reset-password/page.tsx',
    'deploy/upgrade-v3.sh',
    'deploy/backup-v3.sh',
]
for rel in required:
    assert (root / rel).is_file(), rel
plugin = (root / required[0]).read_text()
checkout = (root / 'src/app/api/checkout/route.ts').read_text()
assert 'rsvx7_checkout_guard' in plugin
assert 'INSERT IGNORE INTO' in plugin
assert 'rsvx7_session_user' in plugin
assert "'/checkout/claim'" in checkout
assert "'/checkout/complete'" in checkout
assert 'customerSession()' in checkout
assert 'createHmac' in checkout
assert 'rsvx7_customer_session' in (root / 'src/lib/account-server.ts').read_text()
for file in (root / 'src').rglob('*.ts*'):
    data = file.read_text()
    assert 'WP_BRIDGE_SECRET' not in data, str(file)
    assert "from '@/lib/auth'" not in data, str(file)
if shutil.which('php'):
    check = subprocess.run(['php', '-l', str(root / required[0])], capture_output=True, text=True)
    assert check.returncode == 0, check.stdout + check.stderr
for file in (root / 'deploy').glob('*.sh'):
    check = subprocess.run(['bash', '-n', str(file)], capture_output=True, text=True)
    assert check.returncode == 0, str(file) + check.stderr
print(f'PASS: {len(required)} critical files, PHP syntax, shell scripts, checkout guards')
