#!/usr/bin/env bash
set -Eeuo pipefail
URL="${RSVX7_TEST_URL:-http://127.0.0.1:3010}"
get_status(){ curl -sS -o /dev/null -w '%{http_code}' --max-time 12 "$URL$1"; }
[[ "$(get_status /api/health)" == 200 ]] || { echo 'FAIL: Health endpoint'; exit 1; }
[[ "$(get_status /)" == 200 ]] || { echo 'FAIL: Homepage'; exit 1; }
[[ "$(get_status /account)" == 200 ]] || { echo 'FAIL: Account page'; exit 1; }
[[ "$(get_status /api/account/me)" == 401 ]] || { echo 'FAIL: Private account endpoint'; exit 1; }
[[ "$(get_status /api/account/orders)" == 401 ]] || { echo 'FAIL: Order access'; exit 1; }
[[ "$(get_status /api/download/aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa)" == 401 ]] || { echo 'FAIL: Private download endpoint'; exit 1; }
[[ "$(curl -sS -o /dev/null -w '%{http_code}' --max-time 10 -X POST "$URL/api/checkout" -H 'Origin: https://evil.example' -H 'Content-Type: application/json' -d '{}')" == 403 ]] || { echo 'FAIL: Checkout origin protection'; exit 1; }
echo 'PASS: Health, homepage, account, private endpoints and origin validation'
