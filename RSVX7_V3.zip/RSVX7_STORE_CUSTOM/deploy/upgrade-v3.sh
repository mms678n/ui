#!/usr/bin/env bash
set -Eeuo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$ROOT"
[[ -f .env && -f stack/compose.yaml ]] || { echo 'ERROR: Existing clean WordPress installation not found. Run bootstrap-fresh.sh on a new server.' >&2; exit 1; }
command -v docker >/dev/null && command -v curl >/dev/null || { echo 'ERROR: Docker and curl are required.' >&2; exit 1; }
docker info >/dev/null 2>&1 || { echo 'ERROR: Docker engine is unavailable.' >&2; exit 1; }
WP=rsvx7-wp-wordpress-1
UI=rsvx7-custom-ui
docker inspect "$WP" >/dev/null || { echo 'ERROR: WordPress container missing.' >&2; exit 1; }
[[ -f wordpress/rsvx7-bridge/rsvx7-bridge.php ]] || { echo 'ERROR: Commerce Bridge plugin missing.' >&2; exit 1; }
if command -v php >/dev/null 2>&1; then php -l wordpress/rsvx7-bridge/rsvx7-bridge.php >/dev/null; fi
python3 tests/v3-check.py
bash deploy/backup-v3.sh
STAMP="$(date +%Y%m%d-%H%M%S)"
PREVIOUS=''
if docker inspect "$UI" >/dev/null 2>&1; then
  PREVIOUS="$(docker inspect -f '{{.Image}}' "$UI")"
  docker image tag "$PREVIOUS" "rsvx7-ui-rollback:$STAMP"
fi
mkdir -p .v3-backups
if docker exec "$WP" test -d /var/www/html/wp-content/plugins/rsvx7-bridge; then
  docker cp "$WP:/var/www/html/wp-content/plugins/rsvx7-bridge" ".v3-backups/plugin-$STAMP"
fi
printf '\n=== BUILD STOREFRONT ===\n'
docker compose config --quiet
docker compose --progress plain build storefront
printf '\n=== INSTALL COMMERCE BRIDGE ===\n'
docker exec "$WP" mkdir -p /var/www/html/wp-content/plugins/rsvx7-bridge
docker cp wordpress/rsvx7-bridge/. "$WP:/var/www/html/wp-content/plugins/rsvx7-bridge/"
docker exec "$WP" php -l /var/www/html/wp-content/plugins/rsvx7-bridge/rsvx7-bridge.php
docker exec "$WP" chown -R www-data:www-data /var/www/html/wp-content/plugins/rsvx7-bridge
wp(){ (cd stack && docker compose --profile tools run --rm -T cli "$@"); }
wp plugin activate rsvx7-bridge
wp option update rsvx7_ui_public_url 'https://ui.rsvx7-store.com'
printf '\n=== RUN STOREFRONT ===\n'
docker compose up -d --no-build --force-recreate storefront
success=0
for i in $(seq 1 24); do
  if curl -fsS --max-time 5 http://127.0.0.1:3010/api/health >/dev/null 2>&1; then success=1; break; fi
  sleep 3
done
if [[ "$success" != 1 ]]; then
  echo 'ERROR: UI health check failed.' >&2
  if [[ -n "$PREVIOUS" ]]; then
    docker image tag "$PREVIOUS" rsvx7-custom-ui-storefront:latest
    docker compose up -d --no-build --force-recreate storefront || true
  fi
  exit 1
fi
bash tests/v3-integration.sh
printf '\n=== UPGRADE COMPLETE ===\n'
docker compose ps
printf 'Rollback image: rsvx7-ui-rollback:%s\n' "$STAMP"
printf 'Database volumes and Caddy configuration preserved.\n'
