#!/usr/bin/env bash
# Read-only checks, secrets never printed.
set -Eeuo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$ROOT"
echo '=== NEXT.JS UI ==='
curl -sS --max-time 15 http://127.0.0.1:3010/api/health && echo
for p in / /shop /cart /checkout /account; do
  printf '%-15s ' "$p"
  curl -sS --max-time 15 -o /dev/null -w '%{http_code}\n' "http://127.0.0.1:3010$p" || true
done
echo '=== WORDPRESS ==='
if [[ -f stack/compose.yaml ]]; then
  (cd stack && docker compose ps)
  printf 'WooCommerce activated: '
  (cd stack && docker compose --profile tools run --rm -T cli plugin is-active woocommerce && echo yes) || echo no
  printf 'WooCommerce API: '
  docker exec rsvx7-wp-wordpress-1 php -r '$x=@file_get_contents("http://127.0.0.1/wp-json/wc/store/v1/products"); echo $x===false?"unavailable\n":"reachable\n";' || true
fi
echo '=== UI CONTAINER ==='
docker compose ps
echo '=== TLS: direct to local Caddy ==='
for domain in ui.rsvx7-store.com preview.rsvx7-store.com; do
  printf '%s: ' "$domain"
  curl -sS -o /dev/null -w '%{http_code}\n' --resolve "$domain:443:127.0.0.1" --max-time 12 "https://$domain/" || true
done
echo 'No payments were submitted and no data was deleted.'
