#!/usr/bin/env bash
set -Eeuo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$ROOT"
echo '=== CONTAINERS ==='
docker compose ps
(cd stack && docker compose ps)
echo '=== RESOURCES ==='
df -h /
free -h
echo '=== APPLICATION ==='
for route in / /shop /account /cart /checkout /reset-password /api/health; do
  printf '%-22s ' "$route"
  curl -sS --max-time 12 -o /dev/null -w '%{http_code}\n' "http://127.0.0.1:3010$route" || true
done
echo '=== PLUGINS ==='
(cd stack && docker compose --profile tools run --rm -T cli plugin list --fields=name,status,version --format=table)
echo '=== SECURITY TESTS ==='
bash tests/v3-integration.sh
echo '=== TLS ==='
for domain in ui.rsvx7-store.com preview.rsvx7-store.com; do
  printf '%s ' "$domain"
  curl -sS -o /dev/null -w '%{http_code}\n' --max-time 12 --resolve "$domain:443:127.0.0.1" "https://$domain/" || true
done
