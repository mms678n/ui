#!/usr/bin/env bash
# RSVX7 STORE fresh self-hosted installation: independent WordPress + WooCommerce + Caddy + Next.js.
# Never deletes existing containers, files or Docker volumes.
set -Eeuo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$ROOT"
STACK="$ROOT/stack"
UI_DOMAIN="ui.rsvx7-store.com"
WP_DOMAIN="preview.rsvx7-store.com"
NET="rsvx7-shop-net"

fail(){ echo "ERROR: $*" >&2; exit 1; }
command -v docker >/dev/null || fail 'Docker is not installed. Install Docker Engine and the Compose plugin first.'
command -v python3 >/dev/null || fail 'python3 is required.'
command -v openssl >/dev/null || fail 'openssl is required.'
command -v curl >/dev/null || fail 'curl is required.'
docker info >/dev/null 2>&1 || fail 'Docker daemon is not available.'
docker compose version >/dev/null 2>&1 || fail 'Docker Compose plugin is required.'

printf '\n=== PREFLIGHT ===\n'
free_kb=$(df -Pk "$ROOT" | awk 'NR==2 {print $4}')
if (( free_kb < 5 * 1024 * 1024 )); then fail 'Less than 5 GB of disk space remains. Free space without deleting project databases.'; fi
if [[ -f "$STACK/compose.yaml" || -f "$ROOT/.env" ]]; then
  fail "Existing installation detected. This is fresh-install only; files preserved. Use deploy/verify-fresh.sh to inspect it."
fi
for port in 80 443; do
  if ss -ltnH "( sport = :$port )" 2>/dev/null | grep -q .; then
    ss -ltnp "( sport = :$port )" || true
    fail "Port $port is already in use. No changes made."
  fi
done
if docker container inspect rsvx7-custom-ui >/dev/null 2>&1; then fail 'The UI container already exists. No changes made.'; fi
if docker container inspect rsvx7-wp-wordpress-1 >/dev/null 2>&1; then fail 'A WordPress container already exists. No changes made.'; fi

umask 077
mkdir -p "$STACK"
DB_PASSWORD="$(openssl rand -hex 28)"
DB_ROOT_PASSWORD="$(openssl rand -hex 28)"
WP_ADMIN_PASSWORD="$(openssl rand -hex 20)"
PREVIEW_PASSWORD="$(openssl rand -hex 16)"
RECEIPT_SECRET="$(openssl rand -hex 32)"
PREVIEW_HASH="$(docker run --rm caddy:2.10-alpine caddy hash-password --plaintext "$PREVIEW_PASSWORD")"

cat > "$STACK/.env" <<EOF
DB_PASSWORD=$DB_PASSWORD
DB_ROOT_PASSWORD=$DB_ROOT_PASSWORD
EOF
chmod 600 "$STACK/.env"

cat > "$STACK/compose.yaml" <<'YAML'
name: rsvx7-wp
services:
  db:
    image: mariadb:11.4
    restart: unless-stopped
    environment:
      MARIADB_DATABASE: wordpress
      MARIADB_USER: wordpress
      MARIADB_PASSWORD: ${DB_PASSWORD:?missing}
      MARIADB_ROOT_PASSWORD: ${DB_ROOT_PASSWORD:?missing}
    volumes:
      - rsvx7_db:/var/lib/mysql
    healthcheck:
      test: ['CMD', 'healthcheck.sh', '--connect', '--innodb_initialized']
      interval: 10s
      timeout: 6s
      retries: 20
    networks: [store_net]

  wordpress:
    image: wordpress:php8.3-apache
    restart: unless-stopped
    depends_on:
      db: {condition: service_healthy}
    environment:
      WORDPRESS_DB_HOST: db:3306
      WORDPRESS_DB_USER: wordpress
      WORDPRESS_DB_PASSWORD: ${DB_PASSWORD:?missing}
      WORDPRESS_DB_NAME: wordpress
      WORDPRESS_CONFIG_EXTRA: |
        if (isset($$_SERVER['HTTP_X_FORWARDED_PROTO']) && str_contains($$_SERVER['HTTP_X_FORWARDED_PROTO'], 'https')) {
          $$_SERVER['HTTPS'] = 'on';
        }
        define('DISALLOW_FILE_EDIT', true);
        define('WP_MEMORY_LIMIT', '256M');
    volumes:
      - rsvx7_wp:/var/www/html
    networks: [store_net]

  cli:
    image: wordpress:cli-php8.3
    user: '33:33'
    profiles: ['tools']
    entrypoint: ['wp']
    environment:
      WORDPRESS_DB_HOST: db:3306
      WORDPRESS_DB_USER: wordpress
      WORDPRESS_DB_PASSWORD: ${DB_PASSWORD:?missing}
      WORDPRESS_DB_NAME: wordpress
    volumes:
      - rsvx7_wp:/var/www/html
    networks: [store_net]

  caddy:
    image: caddy:2.10-alpine
    restart: unless-stopped
    ports:
      - '80:80'
      - '443:443'
      - '443:443/udp'
    volumes:
      - ./Caddyfile:/etc/caddy/Caddyfile:ro
      - rsvx7_caddy_data:/data
      - rsvx7_caddy_config:/config
    networks: [store_net]

networks:
  store_net:
    external: true
    name: rsvx7-shop-net

volumes:
  rsvx7_wp:
  rsvx7_db:
  rsvx7_caddy_data:
  rsvx7_caddy_config:
YAML

cat > "$STACK/Caddyfile" <<EOF
$UI_DOMAIN {
    encode zstd gzip
    header X-Robots-Tag "noindex, nofollow"
    reverse_proxy rsvx7-custom-ui:3000
}

$WP_DOMAIN {
    encode zstd gzip
    header X-Robots-Tag "noindex, nofollow"
    basic_auth {
        preview $PREVIEW_HASH
    }
    reverse_proxy wordpress:80
}
EOF
chmod 600 "$STACK/Caddyfile"

cat > "$ROOT/.env" <<EOF
CADDY_NET=$NET
DEMO_MODE=false
WC_INTERNAL_URL=http://rsvx7-wp-wordpress-1
WP_PUBLIC_URL=https://$WP_DOMAIN
WC_ALLOWED_CHECKOUT_METHODS=bacs,cheque
UI_PUBLIC_URL=https://$UI_DOMAIN
WC_RECEIPT_SECRET=$RECEIPT_SECRET
EOF
chmod 600 "$ROOT/.env"

cat > "$ROOT/fresh-access.txt" <<EOF
WORDPRESS ADMIN URL: https://$WP_DOMAIN/wp-admin/
WORDPRESS ADMIN USER: rsvx7admin
WORDPRESS ADMIN PASSWORD: $WP_ADMIN_PASSWORD
WORDPRESS ADMIN EMAIL: admin@rsvx7-store.com (change to an inbox you control)
WORDPRESS PREVIEW BASIC-AUTH USER: preview
WORDPRESS PREVIEW BASIC-AUTH PASSWORD: $PREVIEW_PASSWORD
FRONTEND URL: https://$UI_DOMAIN
EOF
chmod 600 "$ROOT/fresh-access.txt"

if ! docker network inspect "$NET" >/dev/null 2>&1; then docker network create "$NET" >/dev/null; fi
printf '\n=== VERIFY COMPOSE ===\n'
(cd "$STACK" && docker compose config --quiet)
docker compose config --quiet

printf '\n=== BOOT WORDPRESS AND DB ===\n'
(cd "$STACK" && docker compose up -d db wordpress)
for i in $(seq 1 60); do
  if docker exec rsvx7-wp-wordpress-1 test -f /var/www/html/wp-config.php >/dev/null 2>&1; then break; fi
  sleep 2
done
docker exec rsvx7-wp-wordpress-1 test -f /var/www/html/wp-config.php || fail 'WordPress container did not initialize.'
wp(){ (cd "$STACK" && docker compose --profile tools run --rm -T cli "$@"); }

printf '\n=== INSTALL WORDPRESS AND WOOCOMMERCE ===\n'
if wp core is-installed >/dev/null 2>&1; then
  fail 'WordPress is already installed; refusing to overwrite its administrator. Existing data preserved.'
fi
wp core install \
  --url="https://$WP_DOMAIN" \
  --title='RSVX7 STORE' \
  --admin_user='rsvx7admin' \
  --admin_password="$WP_ADMIN_PASSWORD" \
  --admin_email='admin@rsvx7-store.com' \
  --skip-email
wp plugin install woocommerce --activate
docker exec rsvx7-wp-wordpress-1 mkdir -p /var/www/html/wp-content/plugins/rsvx7-bridge
docker cp "$ROOT/wordpress/rsvx7-bridge/." rsvx7-wp-wordpress-1:/var/www/html/wp-content/plugins/rsvx7-bridge/
docker exec rsvx7-wp-wordpress-1 chown -R www-data:www-data /var/www/html/wp-content/plugins/rsvx7-bridge
wp plugin activate rsvx7-bridge
wp option update rsvx7_ui_public_url "https://ui.rsvx7-store.com"
wp rewrite structure '/%postname%/'
wp option update timezone_string 'Europe/Istanbul'
wp option update blog_public 0

printf '\n=== BUILD STOREFRONT ===\n'
# Building the UI doesn't modify WordPress DB volumes or TLS certificates.
docker compose --progress plain build storefront
docker compose up -d --no-build storefront
for i in $(seq 1 30); do
  if curl -fsS --max-time 5 http://127.0.0.1:3010/api/health >/dev/null 2>&1; then break; fi
  sleep 3
done
curl -fsS --max-time 10 http://127.0.0.1:3010/api/health || fail 'UI health check failed; Caddy has not been started.'

printf '\n=== ENABLE CADDY ===\n'
(cd "$STACK" && docker compose up -d caddy)

printf '\n=== INSTALLATION SUMMARY ===\n'
(cd "$STACK" && docker compose ps)
docker compose ps
printf '\nNext.js local home: '
curl -sS -o /dev/null -w '%{http_code}\n' --max-time 15 http://127.0.0.1:3010/
printf 'Woo Store API categories: '
docker exec rsvx7-wp-wordpress-1 php -r '$x=@file_get_contents("http://127.0.0.1/wp-json/wc/store/v1/products/categories"); echo $x===false?"unavailable\n":"reachable\n";' || true
printf '\nSaved credentials: %s/fresh-access.txt (DO NOT SHARE).\n' "$ROOT"
printf 'Create DNS A records ui and preview -> your VPS IP; set DNS only until TLS works.\n'
printf 'Then test with: bash deploy/verify-fresh.sh\n'
