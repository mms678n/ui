#!/usr/bin/env bash
set -Eeuo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$ROOT"
[[ -f stack/compose.yaml ]] || { echo 'ERROR: WordPress stack is missing.' >&2; exit 1; }
wp(){ (cd stack && docker compose --profile tools run --rm -T cli "$@"); }
wp plugin install woo-wallet --activate
wp plugin install license-manager-for-woocommerce --activate
wp plugin list --fields=name,status,version --format=table
printf '\nPlugins installed. Configure store credit, license inventory and gateway settings in WordPress.\n'
