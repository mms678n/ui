import './globals.css'
import type { Metadata } from 'next'
import { SiteHeader } from '@/components/site-header'
import { Footer } from '@/components/footer'
export const metadata: Metadata = { title: { default: 'RSVX7 STORE — Digital by Design', template: '%s | RSVX7 STORE' }, description: 'Digital tools, software and creative resources. RSVX7 STORE.' }
export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return <html lang="en"><body><div className="noise" aria-hidden="true"/><SiteHeader />{children}<Footer /></body></html>
}
