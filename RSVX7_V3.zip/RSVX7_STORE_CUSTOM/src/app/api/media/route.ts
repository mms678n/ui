import { NextResponse } from 'next/server'
import { wpUrl } from '@/lib/woocommerce'
export const dynamic = 'force-dynamic'
const fallback = () => new NextResponse('Image unavailable', { status: 404 })
export async function GET(request: Request) {
  try {
    const url = new URL(request.url)
    const src = url.searchParams.get('src') || ''
    if (src.length > 1600) return fallback()
    const target = new URL(src)
    const expected = new URL(wpUrl)
    if (target.origin !== expected.origin || !target.pathname.startsWith('/wp-content/uploads/') ||
       !/\.(?:png|jpe?g|webp|gif|avif)$/i.test(target.pathname)) return fallback()
    const inner = new URL(process.env.WC_INTERNAL_URL || 'http://rsvx7-wp-wordpress-1')
    const path = target.pathname + target.search
    const resp = await fetch(new URL(path, inner), { redirect: 'manual', cache: 'no-store', headers: { Host: expected.host, 'X-Forwarded-Proto': 'https' }, signal: AbortSignal.timeout(12000) })
    const type = resp.headers.get('content-type') || ''
    const len = Number(resp.headers.get('content-length') || 0)
    if (!resp.ok || !type.startsWith('image/') || type.includes('svg') || (len && len > 8 * 1024 * 1024)) return fallback()
    const bytes = await resp.arrayBuffer()
    if (bytes.byteLength > 8 * 1024 * 1024) return fallback()
    return new NextResponse(bytes, { headers: { 'Content-Type': type, 'Cache-Control': 'public,max-age=1800', 'X-Content-Type-Options': 'nosniff' } })
  } catch { return fallback() }
}
