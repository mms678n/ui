import { bridgeRequest, customerSession, noStore, unauthorized } from '@/lib/account-server'
import { problem } from '@/lib/cart-server'
export const dynamic = 'force-dynamic'
const resources = new Set(['me', 'orders', 'downloads', 'wallet', 'licenses'])
export async function GET(_req: Request, { params }: { params: Promise<{ resource: string }> }) {
  const { resource } = await params
  if (!resources.has(resource)) return problem('Not found.', 404)
  const session = await customerSession()
  if (!session) return unauthorized()
  const result = await bridgeRequest(`/account/${resource}`, 'GET', undefined, session)
  return noStore(result.data, result.status)
}
