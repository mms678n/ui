import { AccountHub } from '@/components/account/account-hub'
export const metadata = { title: 'Wallet — RSVX7 STORE', robots: { index: false, follow: false } }
export default function Wallet() { return <AccountHub initialTab="wallet" /> }
