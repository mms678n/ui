export default function Loading() {
  return <main className="page-main"><div className="container"><div className="route-skeleton-title"/><div className="route-skeleton-grid">{Array.from({ length: 3 }, (_, index) => <div key={index} className="route-skeleton-card"/>)}</div></div></main>
}
