import type { Metadata } from 'next'
import Link from 'next/link'
import { getCategories, getProducts, demoMode } from '@/lib/woocommerce'
import { ProductCard } from '@/components/product-card'
export const metadata: Metadata={ title:'Browse Products' }
export const dynamic='force-dynamic'
export default async function Shop({searchParams}:{searchParams:Promise<{search?:string;category?:string}>}){
 const q=await searchParams;const search=(q.search||'').slice(0,80);const category=(q.category||'').slice(0,30)
 const [products,categories]=await Promise.all([getProducts({search,category,perPage:48}),getCategories()])
 return <main className="page-main"><div className="container"><div className="page-intro"><span className="eyebrow">RSVX7 — PRODUCT INDEX / 001</span><h1>THE <span>COLLECTION.</span></h1><p>Explore our carefully selected digital tools and resources.</p></div>{demoMode&&<div className="demo-banner">DEMO MODE · Sample catalog only — buying is disabled.</div>}<div className="shop-toolbar"><div className="filter-pills" id="categories"><Link className={!category?'active':''} href="/shop">All products</Link>{categories.map(c=><Link key={c.id} className={category===String(c.id)?'active':''} href={`/shop?category=${c.id}`}>{c.name}</Link>)}</div><form action="/shop" method="get" className="search-form"><input name="search" defaultValue={search} placeholder="Search products..." aria-label="Search products"/><button type="submit">SEARCH ↗</button></form></div>{products.length?<div className="products-grid">{products.map((p,i)=><ProductCard key={p.id} product={p} index={i}/>)}</div>:<div className="no-results"><h3>No products found.</h3><p>Try another search, or check that your WooCommerce products are published.</p></div>}</div></main>
}
