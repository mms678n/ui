'use client'
import { useEffect } from 'react'
import Link from 'next/link'
import { ArrowLeft, RotateCw } from 'lucide-react'
export default function ErrorPage({ error, reset }: { error: Error & { digest?: string }; reset: () => void }) {
  useEffect(() => { console.error('Storefront rendering failed:', error.digest || error.message) }, [error])
  return <main className="page-main"><div className="container"><div className="result-panel result-error"><span className="eyebrow">RSVX7 STORE</span><h1>WE HIT A SNAG.</h1><p>This page is temporarily unavailable.</p><div className="error-actions"><button type="button" className="button button-light" onClick={reset}><RotateCw size={18}/> TRY AGAIN</button><Link href="/" className="button button-outline"><ArrowLeft size={18}/> HOME</Link></div></div></div></main>
}
