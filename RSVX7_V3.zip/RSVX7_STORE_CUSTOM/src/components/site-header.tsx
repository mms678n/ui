'use client'

import { useEffect, useState } from 'react'
import Link from 'next/link'
import Image from 'next/image'
import { usePathname, useRouter } from 'next/navigation'
import { AnimatePresence, motion, useReducedMotion, useScroll, useSpring } from 'framer-motion'
import { ArrowUpRight, Menu, Search, ShoppingBag, UserRound, X } from 'lucide-react'

const pages = [
  { label: 'Discover', href: '/' },
  { label: 'Shop', href: '/shop' },
  { label: 'Our Story', href: '/about' },
  { label: 'Account', href: '/account' },
]

export function SiteHeader() {
  const [menuOpen, setMenuOpen] = useState(false)
  const [searchOpen, setSearchOpen] = useState(false)
  const [term, setTerm] = useState('')
  const [count, setCount] = useState(0)
  const pathname = usePathname()
  const router = useRouter()
  const reduced = useReducedMotion()
  const { scrollYProgress } = useScroll()
  const progress = useSpring(scrollYProgress, { stiffness: 120, damping: 32, restDelta: 0.001 })

  useEffect(() => { setMenuOpen(false); setSearchOpen(false) }, [pathname])
  useEffect(() => {
    async function load() {
      try {
        const result = await fetch('/api/cart', { cache: 'no-store' })
        if (result.ok) {
          const cart = await result.json()
          setCount(typeof cart.items_count === 'number' ? cart.items_count : 0)
        }
      } catch { }
    }
    void load()
    window.addEventListener('rsvx7-cart-updated', load)
    return () => window.removeEventListener('rsvx7-cart-updated', load)
  }, [pathname])
  useEffect(() => {
    const listener = (event: KeyboardEvent) => {
      if (event.key === 'Escape') { setMenuOpen(false); setSearchOpen(false) }
      if ((event.metaKey || event.ctrlKey) && event.key.toLowerCase() === 'k') { event.preventDefault(); setSearchOpen(value => !value) }
    }
    window.addEventListener('keydown', listener)
    return () => window.removeEventListener('keydown', listener)
  }, [])

  function search(event: React.FormEvent) {
    event.preventDefault()
    const q = term.trim()
    setSearchOpen(false)
    if (q) router.push(`/shop?search=${encodeURIComponent(q)}`)
    else router.push('/shop')
  }

  return <>
    <header className="site-header header-v3">
      <div className="header-inner">
        <Link className="brand" href="/" onClick={() => setMenuOpen(false)} aria-label="RSVX7 Store home"><span className="brand-symbol"><Image src="/logo-mark.png" alt="" width={26} height={26} /></span><span>RSVX7<span className="brand-light"> / STORE</span></span></Link>
        <nav className="nav-desktop" aria-label="Main navigation">
          {pages.map(page => <Link key={page.href} className={pathname === page.href ? 'nav-current' : ''} href={page.href}>{page.label}</Link>)}
        </nav>
        <div className="header-tools">
          <button className="header-icon-button" type="button" aria-label="Search products" onClick={() => setSearchOpen(true)}><Search size={19}/></button>
          <Link className="header-icon-button header-profile" href="/account" aria-label="Your account"><UserRound size={19}/></Link>
          <Link className="header-cart header-cart-v3" href="/cart" aria-label={`Shopping cart, ${count} items`}><ShoppingBag size={19}/>{count > 0 && <span className="cart-quantity">{count > 99 ? '99+' : count}</span>}</Link>
          <Link className="header-explore" href="/shop">Explore <ArrowUpRight size={15}/></Link>
          <button type="button" className="mobile-toggle" onClick={() => setMenuOpen(value => !value)} aria-expanded={menuOpen} aria-label={menuOpen ? 'Close navigation' : 'Open navigation'}>{menuOpen ? <X size={24}/> : <Menu size={24}/>}</button>
        </div>
      </div>
      <motion.div className="scroll-progress" style={{ scaleX: progress }} />
    </header>
    <AnimatePresence>
      {menuOpen && <motion.nav className="mobile-nav mobile-nav-v3" aria-label="Mobile navigation" initial={reduced ? false : { opacity: 0, y: -18 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -12 }} transition={{ duration: 0.2 }}>{pages.map((page, i) => <Link href={page.href} key={page.href} onClick={() => setMenuOpen(false)}><span className="mobile-menu-index">0{i + 1}</span>{page.label}<ArrowUpRight size={21}/></Link>)}<Link href="/wallet" onClick={() => setMenuOpen(false)}><span className="mobile-menu-index">05</span>Wallet<ArrowUpRight size={21}/></Link></motion.nav>}
    </AnimatePresence>
    <AnimatePresence>
      {searchOpen && <motion.div role="dialog" aria-modal="true" aria-label="Search the store" className="search-overlay" initial={reduced ? false : { opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}><div className="search-overlay-backdrop" onClick={() => setSearchOpen(false)} aria-hidden="true"/><motion.div className="search-dialog" initial={reduced ? false : { y: 28, opacity: 0 }} animate={{ y: 0, opacity: 1 }} exit={{ y: 15, opacity: 0 }}><div className="search-dialog-head"><span className="eyebrow">RSVX7 / SEARCH</span><button type="button" aria-label="Close search" onClick={() => setSearchOpen(false)}><X size={22}/></button></div><form onSubmit={search}><Search size={27}/><input autoFocus type="search" placeholder="Find something extraordinary..." value={term} onChange={e => setTerm(e.target.value)} aria-label="Search products" maxLength={100}/><button type="submit" aria-label="Submit search"><ArrowUpRight size={25}/></button></form><p>PRESS ENTER TO SEARCH <span>·</span> ESC TO CLOSE</p></motion.div></motion.div>}
    </AnimatePresence>
  </>
}
