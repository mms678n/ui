'use client'

import { useCallback, useEffect, useMemo, useState, type FormEvent } from 'react'
import Link from 'next/link'
import { ArrowDownToLine, ArrowRight, CircleUserRound, CreditCard, Eye, EyeOff, KeyRound, LogOut, Package, ShieldCheck, Wallet } from 'lucide-react'

type Profile = { id: number; username: string; name: string; email: string; first_name: string; last_name: string }
type Order = { id: number; number: string; status: string; total: string; currency: string; date: string; items: { name: string; quantity: number }[] }
type Download = { id: string; order_id: number; product_name: string; download_name: string; remaining: string | number; expires: string | null }
type License = { order_id: number; product_id: number; key: string; status: string }
type WalletData = { enabled: boolean; balance?: string; currency?: string }
type Tabs = 'overview' | 'orders' | 'downloads' | 'licenses' | 'wallet'

const menu: { id: Tabs; title: string; Icon: typeof Package }[] = [
  { id: 'overview', title: 'Overview', Icon: CircleUserRound },
  { id: 'orders', title: 'Orders', Icon: Package },
  { id: 'downloads', title: 'Downloads', Icon: ArrowDownToLine },
  { id: 'licenses', title: 'Licenses', Icon: KeyRound },
  { id: 'wallet', title: 'Wallet', Icon: Wallet },
]

async function readApi(path: string, body?: unknown) {
  const response = await fetch(path, {
    method: body === undefined ? 'GET' : 'POST',
    headers: body === undefined ? undefined : { 'Content-Type': 'application/json' },
    body: body === undefined ? undefined : JSON.stringify(body),
    credentials: 'same-origin', cache: 'no-store',
  })
  const result = await response.json().catch(() => ({ error: 'Request failed.' }))
  if (!response.ok) throw new Error(typeof result.error === 'string' ? result.error : 'Request failed.')
  return result
}

function cash(value: string, currency = 'USD') {
  const amount = Number(value)
  if (!Number.isFinite(amount)) return '—'
  try { return new Intl.NumberFormat('en-US', { style: 'currency', currency }).format(amount) }
  catch { return `${amount.toFixed(2)} ${currency}` }
}

export function AccountHub({ initialTab = 'overview' }: { initialTab?: Tabs }) {
  const [profile, setProfile] = useState<Profile | null>(null)
  const [loading, setLoading] = useState(true)
  const [active, setActive] = useState<Tabs>(initialTab)
  const [mode, setMode] = useState<'login' | 'register'>('login')
  const [form, setForm] = useState({ username: '', email: '', password: '', login: '' })
  const [revealPassword, setRevealPassword] = useState(false)
  const [working, setWorking] = useState(false)
  const [message, setMessage] = useState('')
  const [orders, setOrders] = useState<Order[]>([])
  const [downloads, setDownloads] = useState<Download[]>([])
  const [licenses, setLicenses] = useState<License[]>([])
  const [licenseEnabled, setLicenseEnabled] = useState(false)
  const [wallet, setWallet] = useState<WalletData>({ enabled: false })
  const [tabLoading, setTabLoading] = useState(false)

  const refresh = useCallback(async () => {
    try {
      const value = await readApi('/api/account/me') as Profile
      setProfile(value)
    } catch { setProfile(null) }
    finally { setLoading(false) }
  }, [])
  useEffect(() => { void refresh() }, [refresh])

  useEffect(() => {
    if (!profile || active === 'overview') return
    let cancelled = false
    setTabLoading(true)
    setMessage('')
    void (async () => {
      try {
        const result = await readApi(`/api/account/${active}`)
        if (cancelled) return
        if (active === 'orders') setOrders(result.orders || [])
        if (active === 'downloads') setDownloads(result.downloads || [])
        if (active === 'licenses') { setLicenses(result.licenses || []); setLicenseEnabled(result.enabled === true) }
        if (active === 'wallet') setWallet(result)
      } catch (error) { if (!cancelled) setMessage(error instanceof Error ? error.message : 'Request failed.') }
      finally { if (!cancelled) setTabLoading(false) }
    })()
    return () => { cancelled = true }
  }, [active, profile])

  const initials = useMemo(() => (profile?.name || profile?.username || 'R').slice(0, 2).toUpperCase(), [profile])

  async function submit(event: FormEvent) {
    event.preventDefault()
    if (working) return
    setWorking(true)
    setMessage('')
    try {
      const payload = mode === 'login' ? { login: form.login, password: form.password } : { username: form.username, email: form.email, password: form.password }
      await readApi(`/api/auth/${mode}`, payload)
      setForm({ username: '', email: '', password: '', login: '' })
      await refresh()
    } catch (error) { setMessage(error instanceof Error ? error.message : 'Could not sign in.') }
    finally { setWorking(false) }
  }

  async function logout() {
    setWorking(true)
    await readApi('/api/auth/logout', {}).catch(() => undefined)
    setProfile(null)
    setOrders([])
    setDownloads([])
    setLicenses([])
    setWallet({ enabled: false })
    setWorking(false)
    setActive('overview')
  }

  if (loading) return <main className="page-main"><div className="container account-shell"><div className="account-skeleton" aria-label="Loading account" /></div></main>

  if (!profile) return <main className="page-main account-page"><div className="container"><div className="page-intro"><span className="eyebrow">PRIVATE MEMBERS AREA</span><h1>YOUR <span>SPACE.</span></h1><p>Everything you need, all in one place.</p></div><div className="auth-layout"><div className="auth-feature"><span className="eyebrow">RSVX7 / MEMBERS</span><h2>YOUR NEXT<br/><em>MOVE.</em></h2><p>One account for orders, downloads, and digital licenses.</p><div className="auth-orbit" aria-hidden="true"><span>R</span></div><div className="auth-bottom"><ShieldCheck size={19}/> PRIVATE ACCOUNT AREA</div></div><div className="auth-panel"><div className="auth-switch"><button className={mode === 'login' ? 'selected' : ''} onClick={() => { setMode('login'); setMessage('') }} type="button">Sign in</button><button className={mode === 'register' ? 'selected' : ''} onClick={() => { setMode('register'); setMessage('') }} type="button">Create account</button></div><h2>{mode === 'login' ? 'WELCOME BACK.' : 'JOIN RSVX7.'}</h2><p className="auth-subtitle">{mode === 'login' ? 'Sign in to access your digital collection.' : 'Create your customer account.'}</p><form onSubmit={submit} className="auth-form">{mode === 'register' ? <><label>Username<input value={form.username} onChange={e => setForm({ ...form, username: e.target.value })} minLength={3} maxLength={32} autoComplete="username" pattern="[a-zA-Z0-9_-]+" required /></label><label>Email<input value={form.email} onChange={e => setForm({ ...form, email: e.target.value })} type="email" maxLength={160} autoComplete="email" required /></label></> : <label>Username or email<input value={form.login} onChange={e => setForm({ ...form, login: e.target.value })} maxLength={160} autoComplete="username" required /></label>}<label>Password<div className="password-field"><input type={revealPassword ? 'text' : 'password'} value={form.password} onChange={e => setForm({ ...form, password: e.target.value })} minLength={mode === 'register' ? 12 : 1} maxLength={128} autoComplete={mode === 'register' ? 'new-password' : 'current-password'} required /><button type="button" onClick={() => setRevealPassword(!revealPassword)} aria-label={revealPassword ? 'Hide password' : 'Show password'}>{revealPassword ? <EyeOff size={18}/> : <Eye size={18}/>}</button></div></label>{mode === 'login' && <Link href="/reset-password" className="reset-link">Forgot password?</Link>}{message && <p className="error-box" role="alert">{message}</p>}<button className="button button-light full" type="submit" disabled={working}>{working ? 'PLEASE WAIT...' : mode === 'login' ? 'SIGN IN' : 'CREATE ACCOUNT'} <ArrowRight size={18}/></button></form></div></div></div></main>

  return <main className="page-main account-page"><div className="container"><div className="page-intro account-heading"><span className="eyebrow">RSVX7 / MEMBER AREA</span><h1>YOUR <span>SPACE.</span></h1><p>Welcome back, {profile.name || profile.username}.</p></div><div className="account-dashboard"><aside className="account-sidebar"><div className="account-identity"><div className="avatar-mark">{initials}</div><div><strong>{profile.name || profile.username}</strong><span>{profile.email}</span></div></div><nav aria-label="Account sections">{menu.map(({ id, title, Icon }) => <button key={id} type="button" className={active === id ? 'active' : ''} onClick={() => { setActive(id); setMessage('') }}><Icon size={18}/>{title}<ArrowRight size={15} className="account-nav-arrow"/></button>)}</nav><button type="button" className="account-logout" onClick={() => void logout()} disabled={working}><LogOut size={18}/> Sign out</button></aside><section className="account-content"><div className="account-content-title"><span className="eyebrow">MY ACCOUNT</span><h2>{menu.find(item => item.id === active)?.title.toUpperCase()}<span className="period">.</span></h2></div>{message && <p className="error-box" role="alert">{message}</p>}{tabLoading ? <div className="account-skeleton"/> : active === 'overview' ? <div className="account-overview"><div className="overview-primary"><span className="eyebrow">MEMBER PROFILE</span><div className="overview-username">{profile.name || profile.username}</div><p>{profile.email}</p></div><div className="overview-actions"><button onClick={() => setActive('orders')}><Package size={23}/> ORDERS <ArrowRight size={16}/></button><button onClick={() => setActive('downloads')}><ArrowDownToLine size={23}/> DOWNLOADS <ArrowRight size={16}/></button><button onClick={() => setActive('licenses')}><KeyRound size={23}/> LICENSES <ArrowRight size={16}/></button><button onClick={() => setActive('wallet')}><Wallet size={23}/> WALLET <ArrowRight size={16}/></button></div></div> : active === 'orders' ? orders.length ? <div className="account-entries">{orders.map(order => <article key={order.id} className="account-entry"><div><span className="eyebrow">ORDER #{order.number}</span><h3>{order.items.map(item => `${item.name} × ${item.quantity}`).join(' · ') || 'Digital order'}</h3><span className="entry-muted">{order.date ? new Date(order.date).toLocaleDateString('en-US') : ''}</span></div><div className="entry-right"><strong>{cash(order.total, order.currency)}</strong><span className={`order-status status-${order.status}`}>{order.status}</span></div></article>)}</div> : <EmptyState title="No orders yet" text="Explore the store and find something for your next project."/> : active === 'downloads' ? downloads.length ? <div className="account-entries">{downloads.map((item, index) => <article key={item.id + index} className="account-entry"><div><span className="eyebrow">ORDER #{item.order_id}</span><h3>{item.product_name}</h3><span className="entry-muted">{item.download_name}</span></div><a href={`/api/download/${item.id}`} className="small-action"><ArrowDownToLine size={16}/> Download</a></article>)}</div> : <EmptyState title="No downloads yet" text="Purchased downloads will appear here once your payment is confirmed."/> : active === 'licenses' ? !licenseEnabled ? <EmptyState title="Licenses" text="License access is unavailable for this store."/> : licenses.length ? <div className="account-entries">{licenses.map((license, i) => <article key={license.order_id + '-' + i} className="account-entry"><div><span className="eyebrow">ORDER #{license.order_id}</span><h3>Digital license</h3><code className="license-code">{license.key}</code></div><span className="order-status">{license.status}</span></article>)}</div> : <EmptyState title="No licenses yet" text="Your assigned licenses will appear after purchase."/> : wallet.enabled ? <div className="wallet-real"><span className="eyebrow">AVAILABLE STORE BALANCE</span><strong>{cash(wallet.balance || '0', wallet.currency)}</strong><p>Managed securely by WooCommerce.</p><div className="wallet-icon"><CreditCard size={28}/></div></div> : <EmptyState title="Wallet unavailable" text="Store credit will appear when it has been enabled by the store."/>}</section></div></div></main>
}

function EmptyState({ title, text }: { title: string; text: string }) {
  return <div className="account-empty"><span className="empty-symbol" aria-hidden="true">✳</span><h3>{title}</h3><p>{text}</p></div>
}
