import Link from 'next/link'
import { ArrowUpRight } from 'lucide-react'
import type { Product } from '@/lib/types'
import { ProductCard } from './product-card'
import { Reveal } from './reveal'
export function ProductSection({products,title='CURATED TOOLS',sub='Our collection',viewAll=true}:{products:Product[];title?:string;sub?:string;viewAll?:boolean}){
 return <section className="section" id="products"><div className="container"><Reveal className="section-heading"><div><span className="eyebrow"><span className="mini-square"/> {sub}</span><h2>{title}<span className="period">.</span></h2></div>{viewAll&&<Link className="section-link" href="/shop">VIEW ALL PRODUCTS <ArrowUpRight size={17}/></Link>}</Reveal>{products.length ? <div className="products-grid">{products.map((p,i)=><ProductCard key={p.id} product={p} index={i}/>)}</div>:<div className="no-results"><h3>Our catalog is being prepared.</h3><p>Products will appear once WooCommerce is connected and your listings are published.</p></div>}</div></section>
}
