export function money(amount: string | number | undefined, currency = 'USD', minor = 2) {
  if (amount === undefined || amount === null || amount === '') return 'Price unavailable'
  const value = Number(amount) / Math.pow(10, minor)
  if (!Number.isFinite(value)) return 'Price unavailable'
  try { return new Intl.NumberFormat('en-US', { style: 'currency', currency }).format(value) }
  catch { return `${value.toFixed(minor)} ${currency}` }
}
export function priceLabel(prices?: { price: string; currency_code: string; currency_minor_unit: number }) {
  return prices ? money(prices.price, prices.currency_code, prices.currency_minor_unit) : 'Price unavailable'
}
export function cleanText(input?: string) {
  return (input || '').replace(/<[^>]*>/g, ' ').replace(/&nbsp;/g, ' ').replace(/&amp;/g, '&').replace(/&#39;/g, "'").replace(/&quot;/g, '"').replace(/\s+/g, ' ').trim()
}
