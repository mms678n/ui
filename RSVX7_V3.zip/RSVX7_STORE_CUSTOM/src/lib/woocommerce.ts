import type { Product, ProductCategory } from './types'
import { demoCategories, demoProducts } from './demo'

export const demoMode = process.env.DEMO_MODE !== 'false'
export const wpUrl = process.env.WP_PUBLIC_URL || 'https://preview.rsvx7-store.com'
const base = (process.env.WC_INTERNAL_URL || 'http://rsvx7-wp-wordpress-1').replace(/\/+$/, '')
export const storeBase = `${base}/wp-json/wc/store/v1`

async function request<T>(path: string): Promise<T> {
  const res = await fetch(storeBase + path, { cache: 'no-store', headers: { Accept: 'application/json', 'X-Forwarded-Proto': 'https', Host: new URL(wpUrl).host }, signal: AbortSignal.timeout(10000) })
  if (!res.ok) throw new Error(`Store API responded ${res.status}`)
  return res.json() as Promise<T>
}
export async function getProducts(params?: { search?: string; category?: string; perPage?: number }): Promise<Product[]> {
  if (demoMode) return demoProducts.filter(p => (!params?.search || p.name.toLowerCase().includes(params.search.toLowerCase())) && (!params?.category || p.categories?.some(c => c.id === Number(params.category)))).slice(0, params?.perPage || 20)
  const q = new URLSearchParams({ per_page: String(Math.min(params?.perPage || 24, 50)) })
  if (params?.search) q.set('search', params.search)
  if (params?.category) q.set('category', params.category)
  try { return await request<Product[]>(`/products?${q.toString()}`) }
  catch (error) { console.error('Woo products unavailable:', error); return [] }
}
export async function getCategories(): Promise<ProductCategory[]> {
  if (demoMode) return demoCategories
  try { return (await request<ProductCategory[]>('/products/categories?per_page=50')).filter(c => c.slug !== 'uncategorized') }
  catch (error) { console.error('Woo categories unavailable:', error); return [] }
}
export async function getProduct(slug: string): Promise<Product | null> {
  if (demoMode) return demoProducts.find(p => p.slug === slug) || null
  try { return (await request<Product[]>(`/products?slug=${encodeURIComponent(slug)}`))[0] || null }
  catch (error) { console.error('Woo product unavailable:', error); return null }
}
